<?php
$id="$_REQUEST[id]";
$filename = "sudhabhai.xls"; 
            header("Content-Type: application/vnd.ms-excel");
 header("Content-Disposition: attachment; filename=\"$filename\"");
 
 $db_name="localhost";
	$user_name="root";
	$pass="";
	$link=mysql_connect($db_name,$user_name,$pass);
	mysql_select_db('hsptl');
 $query="select * from data";
 $result=mysql_query($query);
 //$data=mysql_fetch_assoc($result);
 //echo "";
 //$heading
 //$total=$data[1]."\t".$data[2]."\t".$data[3];
 //echo $total;
 //exit;
 
 
 
 ExportFile($result);
function ExportFile($records) {
 //$heading = false;
 if(!empty($records))
   /*foreach($records as $row) {
 /*if(!$heading) {
   // display field/column names as a first row
   echo implode("\t", array_keys($row)) . "\n";
   $heading = true;
 }*/
 //echo $row;
 while($data=mysql_fetch_row($records))
 {
  //echo implode("\t", array_values($data)) . "\n";
  $total=$data[1]."\t".mysql_real_escape_string($data[2])."\t".mysql_real_escape_string($data[3])."\n";
  echo $total;
  
   }
 exit;
}


?>