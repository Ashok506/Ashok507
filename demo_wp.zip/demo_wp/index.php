<?php //include('connect.php');

//insert Data
$db_name="localhost";
	$user_name="root";
	$pass="";
	$link=mysql_connect($db_name,$user_name,$pass);
	mysql_select_db('hsptl');

if(isset($_POST['submit']))
{
	$hsptl_name = $_POST['hsptl_name'];
	$hsptl_content = $_POST['hsptl_content'];
	$specialization = $_POST['specialization'];
	

	$sql = "INSERT INTO data(hsptl_name, hsptl_content, specialization) VALUES ('$hsptl_name','$hsptl_content','$specialization')";
	$result = mysql_query($sql);
	
}




?>




<html>
<head>
<script src="//cdn.ckeditor.com/4.5.5/standard/ckeditor.js"></script>
</head>
<body>

<form method="post" action="">

Select<select name="hsptl_name">
<option value="">PLease select</option>
  <option value="volvo">Volvo</option>
  <option value="saab">Saab</option>
  <option value="mercedes">Mercedes</option>
  <option value="audi">Audi</option>
</select>
<br><br><br>

specialization : <input type="text" name="specialization" >
<br><br><br>

Content : <textarea name="hsptl_content" id="text"></textarea>
<br><br><br>


<input type="submit" name="submit" value="Submit">
</form>

<table width="100%" border="2px">
<?php

$query= "select * from data";

$result = mysql_query($query);

$i=0;


while($row = mysql_fetch_row($result))	
{
	$i++;
	?>
	
	<tr>
	<td><?php echo $i; ?></td>
	<td><?php echo $row[1]; ?></td>
	<td><?php echo $row[2]; ?></td>
	<td><a href="download.php?id=<?php echo $row[0];?>">Download</a></td>
	
	
	
	
	
	</tr>
	
	<?php

}
?>
</table>

</body>
<script> CKEDITOR.replace( 'text' );</script>


</html>